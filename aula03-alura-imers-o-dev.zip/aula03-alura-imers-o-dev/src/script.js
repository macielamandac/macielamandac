let rodada = 1;
let totalRodadas;
alert("nivel facil: 1 rodada, nivel medio: 3 rodadas, nivel dificil: 4 rodadas");
let escolhajogador = prompt("escolha um nivel de dificuldade: facil, medio ou dificil");
if (escolhajogador == "facil") {
  totalRodadas = 1;
} else if (escolhajogador == "medio") {
  totalRodadas = 3;
} else if (escolhajogador == "dificil") {
  totalRodadas = 4;
} else {
  alert("Nível inválido!");
  totalRodadas = 0;
}
while (rodada <= totalRodadas) {
  console.log("rodada " + rodada);
  let escolhapcnum = Math.floor(Math.random() * (escolhajogador == "dificil" ? 5 : 3)) + 1;
  let escolhaJogadorNum;
  do {
    escolhaJogadorNum = parseInt(prompt("Escolha um número de 1 a " + (escolhajogador == "dificil" ? 5 : 3)));
    if (escolhajogador == "dificil" && (escolhaJogadorNum < 1 || escolhaJogadorNum > 5)) {
      alert("Escolha um número entre 1 e 5.");
    } else if (escolhajogador != "dificil" && (escolhaJogadorNum < 1 || escolhaJogadorNum > 3)) {
      alert("Escolha um número entre 1 e 3.");
    }
  } while ((escolhajogador == "dificil" && (escolhaJogadorNum < 1 || escolhaJogadorNum > 5)) ||
            (escolhajogador != "dificil" && (escolhaJogadorNum < 1 || escolhaJogadorNum > 3)));
  alert("O vidro quebrado estava no número " + escolhapcnum);
  if (escolhapcnum == escolhaJogadorNum) {
    alert("você perdeu! o vidro quebrou");
    break;
  } else {
    alert("você ganhou! o vidro não quebrou");
    if (rodada > 1) {
      alert("Você passou para a próxima rodada!");
    }
  }  
  rodada++;
}
if (rodada > totalRodadas) {
  alert("PARABÉNS! Você completou todas as rodadas!");
}