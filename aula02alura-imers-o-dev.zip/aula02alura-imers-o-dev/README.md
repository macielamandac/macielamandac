# Aula02 - Alura Imersão dev

A Pen created on CodePen.

Original URL: [https://codepen.io/Amanda-Maciel/pen/NPWepbv](https://codepen.io/Amanda-Maciel/pen/NPWepbv).

Imersão dev - Alura - aula 2: edições Amanda Maciel