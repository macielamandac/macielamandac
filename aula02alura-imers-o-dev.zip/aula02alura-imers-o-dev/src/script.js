 alert("vamos começar a jogar!")
 escolhaJogador = prompt("PAR ou ÍMPAR")
   if (escolhaJogador == "PAR"){
    escolhaPC = "ÍMPAR"
      alert("escolhaPC foi ÍMPAR")
   }
   if (escolhaJogador =="ÍMPAR"){
    escolhaPC = "PAR"
     alert("escolhaPC foi PAR")
   }
escolhaJogadornum = prompt("escolha um número de 1 a 5")
escolhaComputadornumero = Math.floor(Math.random() * 5) + 1
 {
  escolhaPC = escolhaComputadornumero
    alert("a escolha do pc foi "+ escolhaPC)
  }
soma = Number(escolhaJogadornum) + Number(escolhaPC)
  
 if ((escolhaJogador == "PAR") && ((soma == 10) || (soma == 8) || (soma == 6) || (soma == 4) || (soma == 2))){
   alert("você VENCEU!")}
  
 if ((escolhaJogador == "ÍMPAR") && ((soma == 9) || (soma == 7) || (soma == 5) || (soma == 3))){
   alert("você VENCEU!")}
  
 if ((escolhaJogador == "ÍMPAR") && ((soma == 10) || (soma == 8) || (soma == 6) || (soma == 4) || (soma == 2))){
     alert("você perdeu!")}
  
 if ((escolhaJogador == "PAR") && ((soma == 9) || (soma == 7) || (soma == 5) || (soma == 3))){
     alert("você perdeu!")}
