# AULA1 _Alura Imersão dev

A Pen created on CodePen.

Original URL: [https://codepen.io/Amanda-Maciel/pen/PwoXPGM](https://codepen.io/Amanda-Maciel/pen/PwoXPGM).

Conversor de Celsius em Fahrenheit - Aula 1: edições Amanda Maciel