valorcelsius = prompt("digite um valor celsius")
taxaconversaocelsius = 1.8
alert(valorcelsius * taxaconversaocelsius + 32 + "°F")