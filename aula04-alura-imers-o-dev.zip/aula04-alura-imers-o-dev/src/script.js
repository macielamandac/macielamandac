// Escolha dos Animais
const animais = ["Leão", "Tigre", "Elefante", "Urso", "Águia"];
const animaisComputador = [...animais]; // O computador também tem os mesmos animais

// Função para gerar força aleatória
function gerarForca() {
    return Math.floor(Math.random() * 10) + 1; // Força entre 1 e 10
}

// Variáveis para armazenar a força total
let forcaJogador = 0;
let forcaComputador = 0;

// Sistema de pontos
let pontosJogador = 0;

// Escolha dos animais pelo jogador
let escolhaJogador = [];
for (let i = 0; i < 3; i++) {
    let escolha = prompt(`Escolha seu animal ${i + 1} (Leão, Tigre, Elefante, Urso, Águia):`);
    if (animais.includes(escolha)) {
        escolhaJogador.push(escolha);
        forcaJogador += gerarForca(); // Adiciona força aleatória para o animal escolhido
    } else {
        alert("Escolha inválida! Tente novamente.");
        i--; // Decrementa i para repetir a escolha
    }
}

// Escolha aleatória do computador
let escolhaComputador = [];
for (let i = 0; i < 3; i++) {
    let indiceAleatorio = Math.floor(Math.random() * animaisComputador.length);
    let animalEscolhido = animaisComputador[indiceAleatorio];
    escolhaComputador.push(animalEscolhido);
    forcaComputador += gerarForca(); // Adiciona força aleatória para o animal escolhido
    animaisComputador.splice(indiceAleatorio, 1); // Remove o animal escolhido da lista
}

// Comparação de Forças
alert(`Seu time: ${escolhaJogador.join(", ")} com força total: ${forcaJogador}`);
alert(`Time do computador: ${escolhaComputador.join(", ")} com força total: ${forcaComputador}`);

if (forcaJogador > forcaComputador) {
    alert("Você ganhou a batalha! 🎉");
    pontosJogador += 1; // Adiciona ponto ao jogador
} else if (forcaJogador < forcaComputador) {
    alert("O computador ganhou a batalha! 😢");
    pontosJogador -= 1; // Remove ponto do jogador
} else {
    alert("Empate! Ambos os times têm a mesma força. 🤝");
}
